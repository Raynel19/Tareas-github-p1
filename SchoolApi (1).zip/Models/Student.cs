using System.ComponentModel.DataAnnotations;

namespace SchoolApi.Models;

public class Student
{
    public int Id { get; set; }

    [Required]
    [MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;

    public List<Course> Courses { get; set; } = new();
}
