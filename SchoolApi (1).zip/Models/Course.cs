using System.ComponentModel.DataAnnotations;

namespace SchoolApi.Models;

public class Course
{
    public int Id { get; set; }

    [Required]
    [MaxLength(100)]
    public string Title { get; set; } = string.Empty;

    public int StudentId { get; set; }
    public Student? Student { get; set; }
}
