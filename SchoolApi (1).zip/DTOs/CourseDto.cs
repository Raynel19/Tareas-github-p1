namespace SchoolApi.DTOs;

public class CourseDto
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public int StudentId { get; set; }
}
