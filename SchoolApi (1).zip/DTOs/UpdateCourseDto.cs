using System.ComponentModel.DataAnnotations;

namespace SchoolApi.DTOs;

public class UpdateCourseDto
{
    [Required]
    public string Title { get; set; } = string.Empty;

    [Required]
    public int StudentId { get; set; }
}
