using System.ComponentModel.DataAnnotations;

namespace SchoolApi.DTOs;

public class CreateCourseDto
{
    [Required]
    public string Title { get; set; } = string.Empty;

    [Required]
    public int StudentId { get; set; }
}
